from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3, os
from datetime import datetime

app = Flask(__name__)
app.secret_key = "franchiseos-dev-key"
DB = os.path.join(os.path.dirname(__file__), "franchiseos.db")

def db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = db()
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS branches(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        city TEXT NOT NULL,
        manager TEXT,
        status TEXT DEFAULT 'Active'
    );
    CREATE TABLE IF NOT EXISTS employees(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        role TEXT NOT NULL,
        branch_id INTEGER NOT NULL,
        salary REAL DEFAULT 0,
        status TEXT DEFAULT 'Active',
        FOREIGN KEY(branch_id) REFERENCES branches(id)
    );
    CREATE TABLE IF NOT EXISTS products(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sku TEXT UNIQUE NOT NULL,
        name TEXT NOT NULL,
        category TEXT,
        price REAL NOT NULL,
        stock INTEGER DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS suppliers(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        contact TEXT,
        city TEXT
    );
    CREATE TABLE IF NOT EXISTS sales(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        branch_id INTEGER NOT NULL,
        product_id INTEGER NOT NULL,
        quantity INTEGER NOT NULL,
        total REAL NOT NULL,
        sale_date TEXT NOT NULL,
        FOREIGN KEY(branch_id) REFERENCES branches(id),
        FOREIGN KEY(product_id) REFERENCES products(id)
    );
    CREATE TABLE IF NOT EXISTS stock_transfers(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        product_id INTEGER NOT NULL,
        from_branch INTEGER,
        to_branch INTEGER,
        quantity INTEGER NOT NULL,
        status TEXT DEFAULT 'Pending',
        transfer_date TEXT NOT NULL
    );
    """)
    if conn.execute("SELECT COUNT(*) FROM branches").fetchone()[0] == 0:
        conn.executemany("INSERT INTO branches(name,city,manager) VALUES(?,?,?)", [
            ("Connaught Place","New Delhi","Aarav Sharma"),
            ("Gurugram Central","Gurugram","Riya Mehta"),
            ("Noida Sector 18","Noida","Kabir Singh")
        ])
        conn.executemany("INSERT INTO employees(name,role,branch_id,salary) VALUES(?,?,?,?)", [
            ("Neha Kapoor","Store Manager",1,62000),("Rahul Verma","Sales Executive",1,36000),
            ("Ankit Jain","Store Manager",2,64000),("Pooja Rao","Sales Executive",2,35000),
            ("Vikram Das","Store Manager",3,61000)
        ])
        conn.executemany("INSERT INTO products(sku,name,category,price,stock) VALUES(?,?,?,?,?)", [
            ("SKU-1001","Premium Coffee","Beverages",249,180),
            ("SKU-1002","Classic Sandwich","Food",179,95),
            ("SKU-1003","Chocolate Muffin","Bakery",129,130),
            ("SKU-1004","Cold Brew","Beverages",299,72),
            ("SKU-1005","Veg Wrap","Food",199,110)
        ])
        conn.executemany("INSERT INTO suppliers(name,contact,city) VALUES(?,?,?)", [
            ("FreshSupply India","+91 98765 10001","Delhi"),
            ("Metro Foods","+91 98765 10002","Gurugram"),
            ("Urban Beverages","+91 98765 10003","Noida")
        ])
        now = datetime.now().strftime("%Y-%m-%d")
        conn.executemany("INSERT INTO sales(branch_id,product_id,quantity,total,sale_date) VALUES(?,?,?,?,?)", [
            (1,1,14,3486,now),(1,2,9,1611,now),(2,4,11,3289,now),
            (2,3,16,2064,now),(3,5,12,2388,now),(3,1,8,1992,now)
        ])
    conn.commit()
    conn.close()

@app.route("/")
def dashboard():
    conn=db()
    stats = {
        "branches": conn.execute("SELECT COUNT(*) c FROM branches").fetchone()["c"],
        "employees": conn.execute("SELECT COUNT(*) c FROM employees WHERE status='Active'").fetchone()["c"],
        "products": conn.execute("SELECT COUNT(*) c FROM products").fetchone()["c"],
        "sales": conn.execute("SELECT COALESCE(SUM(total),0) s FROM sales").fetchone()["s"],
        "units": conn.execute("SELECT COALESCE(SUM(quantity),0) q FROM sales").fetchone()["q"],
    }
    branch_sales = conn.execute("""
        SELECT b.name, COALESCE(SUM(s.total),0) total
        FROM branches b LEFT JOIN sales s ON b.id=s.branch_id
        GROUP BY b.id ORDER BY total DESC
    """).fetchall()
    top_products = conn.execute("""
        SELECT p.name, SUM(s.quantity) units, SUM(s.total) revenue
        FROM products p JOIN sales s ON p.id=s.product_id
        GROUP BY p.id ORDER BY revenue DESC LIMIT 5
    """).fetchall()
    conn.close()
    return render_template("dashboard.html", stats=stats, branch_sales=branch_sales, top_products=top_products)

@app.route("/branches", methods=["GET","POST"])
def branches():
    conn=db()
    if request.method=="POST":
        conn.execute("INSERT INTO branches(name,city,manager) VALUES(?,?,?)",
                     (request.form["name"],request.form["city"],request.form["manager"]))
        conn.commit(); flash("Branch created successfully.")
        return redirect(url_for("branches"))
    rows=conn.execute("SELECT * FROM branches ORDER BY id DESC").fetchall()
    conn.close(); return render_template("branches.html", rows=rows)

@app.route("/employees", methods=["GET","POST"])
def employees():
    conn=db()
    if request.method=="POST":
        conn.execute("INSERT INTO employees(name,role,branch_id,salary) VALUES(?,?,?,?)",
                     (request.form["name"],request.form["role"],request.form["branch_id"],request.form["salary"]))
        conn.commit(); flash("Employee added.")
        return redirect(url_for("employees"))
    rows=conn.execute("""SELECT e.*, b.name branch FROM employees e
                         JOIN branches b ON b.id=e.branch_id ORDER BY e.id DESC""").fetchall()
    branch_list=conn.execute("SELECT * FROM branches").fetchall()
    conn.close(); return render_template("employees.html", rows=rows, branches=branch_list)

@app.route("/inventory", methods=["GET","POST"])
def inventory():
    conn=db()
    if request.method=="POST":
        conn.execute("INSERT INTO products(sku,name,category,price,stock) VALUES(?,?,?,?,?)",
                     (request.form["sku"],request.form["name"],request.form["category"],
                      request.form["price"],request.form["stock"]))
        conn.commit(); flash("Product added to central inventory.")
        return redirect(url_for("inventory"))
    rows=conn.execute("SELECT * FROM products ORDER BY id DESC").fetchall()
    conn.close(); return render_template("inventory.html", rows=rows)

@app.route("/sales", methods=["GET","POST"])
def sales():
    conn=db()
    if request.method=="POST":
        pid=int(request.form["product_id"]); qty=int(request.form["quantity"]); bid=int(request.form["branch_id"])
        p=conn.execute("SELECT * FROM products WHERE id=?", (pid,)).fetchone()
        if not p or p["stock"] < qty:
            flash("Insufficient central inventory."); return redirect(url_for("sales"))
        total=p["price"]*qty
        conn.execute("INSERT INTO sales(branch_id,product_id,quantity,total,sale_date) VALUES(?,?,?,?,?)",
                     (bid,pid,qty,total,datetime.now().strftime("%Y-%m-%d")))
        conn.execute("UPDATE products SET stock=stock-? WHERE id=?", (qty,pid))
        conn.commit(); flash(f"Sale recorded: ₹{total:,.2f}")
        return redirect(url_for("sales"))
    rows=conn.execute("""SELECT s.*,b.name branch,p.name product
                         FROM sales s JOIN branches b ON b.id=s.branch_id
                         JOIN products p ON p.id=s.product_id ORDER BY s.id DESC""").fetchall()
    products=conn.execute("SELECT * FROM products WHERE stock>0").fetchall()
    branch_list=conn.execute("SELECT * FROM branches WHERE status='Active'").fetchall()
    conn.close(); return render_template("sales.html", rows=rows, products=products, branches=branch_list)

@app.route("/suppliers", methods=["GET","POST"])
def suppliers():
    conn=db()
    if request.method=="POST":
        conn.execute("INSERT INTO suppliers(name,contact,city) VALUES(?,?,?)",
                     (request.form["name"],request.form["contact"],request.form["city"]))
        conn.commit(); flash("Supplier added.")
        return redirect(url_for("suppliers"))
    rows=conn.execute("SELECT * FROM suppliers ORDER BY id DESC").fetchall()
    conn.close(); return render_template("suppliers.html", rows=rows)

@app.route("/transfers", methods=["GET","POST"])
def transfers():
    conn=db()
    if request.method=="POST":
        pid=int(request.form["product_id"]); qty=int(request.form["quantity"])
        p=conn.execute("SELECT * FROM products WHERE id=?", (pid,)).fetchone()
        if not p or p["stock"] < qty:
            flash("Insufficient central stock for transfer.")
        else:
            conn.execute("""INSERT INTO stock_transfers(product_id,from_branch,to_branch,quantity,status,transfer_date)
                            VALUES(?,?,?,?,?,?)""",
                         (pid,request.form["from_branch"],request.form["to_branch"],qty,"Approved",
                          datetime.now().strftime("%Y-%m-%d")))
            conn.execute("UPDATE products SET stock=stock-? WHERE id=?", (qty,pid))
            conn.commit(); flash("Stock transfer created.")
        return redirect(url_for("transfers"))
    rows=conn.execute("""SELECT t.*,p.name product,f.name from_branch_name,tb.name to_branch_name
                         FROM stock_transfers t JOIN products p ON p.id=t.product_id
                         LEFT JOIN branches f ON f.id=t.from_branch
                         LEFT JOIN branches tb ON tb.id=t.to_branch
                         ORDER BY t.id DESC""").fetchall()
    products=conn.execute("SELECT * FROM products WHERE stock>0").fetchall()
    branch_list=conn.execute("SELECT * FROM branches").fetchall()
    conn.close(); return render_template("transfers.html", rows=rows, products=products, branches=branch_list)

@app.route("/reports")
def reports():
    conn=db()
    by_branch=conn.execute("""SELECT b.name,COUNT(s.id) transactions,
        COALESCE(SUM(s.quantity),0) units,COALESCE(SUM(s.total),0) revenue
        FROM branches b LEFT JOIN sales s ON b.id=s.branch_id GROUP BY b.id ORDER BY revenue DESC""").fetchall()
    by_category=conn.execute("""SELECT p.category,SUM(s.quantity) units,SUM(s.total) revenue
        FROM products p JOIN sales s ON p.id=s.product_id GROUP BY p.category ORDER BY revenue DESC""").fetchall()
    conn.close(); return render_template("reports.html", by_branch=by_branch, by_category=by_category)

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
