# 🏪 FranchiseOS — Multi-Branch Business Management System

FranchiseOS is a portfolio-grade business management platform designed for a franchise or retail organization operating multiple outlets.

## Core Modules

- **Multi-branch management** — create and monitor outlets across cities.
- **Central inventory** — SKU, category, price and stock tracking.
- **Branch-level sales** — record transactions against specific outlets.
- **Employee management** — assign employees, roles and salaries to branches.
- **Supplier management** — maintain supplier directory.
- **Stock transfers** — move central inventory between branches with transfer records.
- **Consolidated reporting** — compare branch revenue, transaction volume, units sold and category performance.
- **Dashboard analytics** — KPIs, branch revenue ranking and top products.

## Tech Stack

- Python 3.10+
- Flask
- SQLite
- Jinja2
- HTML5 / CSS3
- Vanilla JavaScript

## Project Structure

```text
FranchiseOS/
├── app.py
├── requirements.txt
├── README.md
├── franchiseos.db        # generated automatically on first run
├── templates/
│   ├── base.html
│   ├── dashboard.html
│   ├── branches.html
│   ├── employees.html
│   ├── inventory.html
│   ├── sales.html
│   ├── suppliers.html
│   ├── transfers.html
│   └── reports.html
└── static/
    └── style.css
```

## Run Locally

```bash
python -m venv venv
```

Windows:

```bash
venv\Scripts\activate
```

macOS/Linux:

```bash
source venv/bin/activate
```

Install dependencies:

```bash
pip install -r requirements.txt
```

Start:

```bash
python app.py
```

Open:

```text
http://127.0.0.1:5000
```

The application creates and seeds `franchiseos.db` automatically.

## Portfolio Highlights

This project demonstrates relational database design, CRUD operations, transactional inventory updates, branch-level aggregation, reporting queries, validation, server-side rendering, and a modular business workflow.

## Future Enhancements

- Role-based authentication
- REST API
- JWT authentication
- PostgreSQL support
- Redis caching
- Docker deployment
- Branch-level inventory rather than central-only inventory
- Purchase-order workflow
- GST/tax reporting
- Advanced charts using Chart.js
- Audit logs
- CSV/PDF export
- Cloud deployment
